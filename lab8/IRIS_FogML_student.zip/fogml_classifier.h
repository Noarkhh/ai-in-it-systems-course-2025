#ifndef __FOGML_CLASSIFIER_H__
#define __FOGML_CLASSIFIER_H__

#ifdef __cplusplus
extern "C" {
#endif

int classifier(float *x);

#ifdef __cplusplus
} // extern "C"
#endif

#endif
