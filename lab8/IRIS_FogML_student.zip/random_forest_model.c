//TODO
int classifier(float * x){

  return 0;
}